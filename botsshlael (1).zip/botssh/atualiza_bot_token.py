import sqlite3
from time import sleep

def obter_resposta():
    resposta = input('Alterou o token do bot no @botfather? (s/n): ')
    if resposta == 's':
        def obter_token():
            novo_token = input('Qual o novo token do seu bot? ')
            print(f'Você informou que seu novo token é {novo_token}\n')
            resposta = input('Essa informação está correta? (s/n): ')
            if resposta == 's':
                try:
                    with sqlite3.connect('/modules/botssh/database.db') as con:
                        cursor = con.cursor()
                        cursor.execute('UPDATE bot_config SET bot_token = ? WHERE id = 1', (novo_token,))
                        print('Token Atualizado com sucesso!')
                        sleep(1)
                except sqlite3.Error as e:
                    print(f'\nSeu token não foi atualizado automaticamente. Erro: {e}\n')
                    print('A restauração será feita com o token anterior mesmo\n')
                    print('Quando finalizar, entre em contato com o suporte para atualizar seu token manualmente\n\n')
                    input('Digite enter para continuar:')
            elif resposta == 'n':
                obter_token()
            else:
                print('Resposta inválida!')
                obter_token()
        obter_token()
    elif resposta == 'n':
        print('Ok, prosseguindo com a restauração...\n')
        sleep(2)
    else:
        print('Resposta inválida! digite "s" para sim ou "n" para não....')
        sleep(1)
        obter_resposta()

obter_resposta()
