import time
import sqlite3
import mercadopago
import telebot
import random
import secrets
import string
import pathlib
import subprocess
import uuid
import datetime
import os
import json
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from io import BytesIO
from PIL import Image

# Obter token do bot
with sqlite3.connect('database.db') as con:
    cursor = con.cursor()
    cursor.execute('SELECT bot_token FROM bot_config')
    resposta = cursor.fetchone()
    TOKEN = str(resposta[0])

# Cria instancia do bot, com o token do arquivo token_bot.py
#bot = telebot.TeleBot('5335702344:AAFHOcR_4Ng-LuyPYYAOaBHATDlaJC2P7b0', parse_mode="HTML")  # TESTES
bot = telebot.TeleBot(TOKEN, parse_mode="HTML")  # Produção

# ============== Conectar ao banco de dados e obter o token do mercado pago ===================== #
# =============================================================================================== #
def obter_token_mp():
    with sqlite3.connect('database.db') as con:
        cursor = con.cursor()
        cursor.execute('SELECT token_mp FROM bot_config;')
        dados = cursor.fetchone()
    token_mp = str(dados[0])
    return token_mp

# Função para verificar status dos pagamentos de cada compra registrada no banco de dados
def check_status():
    while True:
        try:
            token_mp = obter_token_mp()
            sdk = mercadopago.SDK(token_mp)

            with sqlite3.connect('database.db') as con:
                cursor = con.cursor()
                cursor.execute("SELECT user_id, id_compra, limite, validade, cliente, msg_pix_id FROM compras WHERE status = 'pendente'")
                compras_pendentes = cursor.fetchall()
                for dados in compras_pendentes:
                    chat_id = str(dados[0])
                    compra = dados[1]
                    limite = dados[2]
                    validade = dados[3]
                    nome = dados[4]
                    msg_pix_id = dados[5]

                    # Realizar a verificação do status da compra usando a API do Mercado Pago
                    payments = sdk.payment().get(compra)
                    status = payments['response']['status']

                    # Verificar o status da compra
                    if status == "approved":
                        # realizar ação necessária para compra aprovada
                        print(f"Compra {compra} aprovada!")

                        # Obter o valor pago
                        valor_pago = payments['response']['transaction_details']['total_paid_amount']
                        print(f"Compra {compra} aprovada! Valor pago: {valor_pago}")

                        app_link = obter_app_link()

                        if app_link:
                            # Criar string com letras e números possíveis
                            dicionario = string.ascii_letters + string.digits

                            # Define o número mínimo e máximo de caracteres
                            no_minimo = 4
                            no_maximo = 8

                            # Cria um login e senha com caracteres aleatórios
                            login = ''.join(secrets.choice(dicionario) for i in range(random.randint(no_minimo, no_maximo)))
                            senha = ''.join(secrets.choice(string.digits) for i in range(random.randint(no_minimo, no_maximo)))

                            # Cria o comando para gerar a conta SSH
                            comando = f"{pathlib.Path.cwd()}/criarusuario.sh {login} {senha} {validade} {limite}"
                            os.system(comando)

                            # Calcular a data de vencimento
                            validade_data = (datetime.datetime.now() + datetime.timedelta(days=validade - 1)).strftime("%d/%m/%Y")
                            data_iso_format = (datetime.datetime.now() + datetime.timedelta(days=validade - 1)).strftime("%d-%m-%Y")

                            v2ray_uuid = None
                            config_json_path = "/etc/v2ray/config.json"
                            if os.path.exists(config_json_path):
                                v2ray_uuid = str(uuid.uuid4())

                                # Informações para adicionar ao arquivo config.json
                                entry = {
                                    "email": login,
                                    "id": v2ray_uuid,
                                    "level": 0,
                                }

                                # Abra o arquivo config.json para leitura e carregue seu conteúdo como um objeto JSON
                                with open(config_json_path, 'r') as config_file:
                                    config_data = json.load(config_file)

                                # Adicione a nova entrada à matriz "clients" no objeto JSON
                                config_data["inbounds"][0]["settings"]["clients"].append(entry)

                                # Abra o arquivo config.json para escrita e escreva o objeto JSON atualizado
                                with open(config_json_path, 'w') as config_file:
                                    json.dump(config_data, config_file, indent=4)
                                # Adicione informações ao arquivo /etc/SSHPlus/RegV2ray
                                os.system(f'echo "{v2ray_uuid} | {login} | {validade_data}" >> /etc/SSHPlus/RegV2ray')

                                # Reinicie o serviço V2Ray
                                subprocess.run(["systemctl", "restart", "v2ray"])
                            
                            # Testar se as variaveis estão corretas:
                            print(f"chat_id: {chat_id}\ncompra: {compra}\nlogin: {login}\nsenha: {senha}\nv2ray_uuid: {v2ray_uuid}\nlimite: {limite}\ndata: {data_iso_format}")

                            # Adicionar informações do cliente no banco de dados
                            try:
                                cursor.execute("INSERT INTO contas_vip (user_id, id_pagamento, login, senha, uuid, limite, vencimento) VALUES (?, ?, ?, ?, ?, ?, ?)", (chat_id, compra, login, senha, v2ray_uuid, limite, data_iso_format))
                                con.commit()
                                print("Dados do cliente inseridos com sucesso!")
                            except sqlite3.Error as e:
                                print(f"Erro ao inserir dados: {e}")

                            # Crie o menu de botões (inlinekeyboard)
                            menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                            app_button = telebot.types.InlineKeyboardButton("📥 Baixar nosso APP", callback_data="baixar_app")
                            back_button = InlineKeyboardButton("🔙 Voltar ao início", callback_data="voltar_ao_inicio")
                            menu.add(app_button, back_button)

                            # Crie a mensagem com as informações para o usuário
                            mensagem = f'<b>Olá, {nome}! Sua compra foi aprovada! ✅</b>\n'
                            mensagem += f'🆔 <b>ID da Compra:</b> <code>{compra}</code>\n\n'
                            mensagem += f'💡 <i><b>Dica:</b> Clique no usuário para copiá-lo automaticamente e cole no aplicativo. Repita o mesmo processo para a senha!</i>\n\n'
                            mensagem += f'👑 <b>Sua conta SSH VIP:</b> 🌟\n\n'
                            mensagem += f'👤 <b>Login:</b> <code>{login}</code>\n'
                            mensagem += f'🔐 <b>Senha:</b> <code>{senha}</code>\n'
                            if os.path.exists(config_json_path):
                                mensagem += f'🔑 <b>UUID V2Ray:</b> <code>{v2ray_uuid}</code>\n'
                            mensagem += f'📱 <b>Limite de dispositivos:</b> {limite}\n'
                            mensagem += f'📅 <b>Validade:</b> {validade} dias - {validade_data}\n\n'
                            mensagem += f'⚠️ <b>AVISO!</b> Seu login VIP poderá ser visualizado a qualquer momento. basta acessar o <b>Painel do Cliente</b> (disponível no menu inicial).'

                            try:
                                bot.send_message(chat_id, mensagem, parse_mode="HTML", reply_markup=menu)
                            except telebot.apihelper.ApiException as e:
                                print(f"Erro ao enviar os dados ao cliente: {e}")
                                # Não continue ou interrompa o fluxo, só logue o erro

                            time.sleep(1)

                            # Obter lista de grupos e canais para enviar notificação
                            bot_info = bot.get_me()
                            bot_link = f"https://t.me/{bot_info.username}"
                            
                            cursor.execute("SELECT user_id FROM leads WHERE user_id < 0")
                            leads = cursor.fetchall()
                            # Enviar notificação para todos os grupos e canais da lista de leads
                            for lista in leads:
                                canal = lista[0]
                                try:
                                    menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                                    bot_button = telebot.types.InlineKeyboardButton(text='🛍️ COMPRAR LOGIN VIP', url=bot_link)
                                    menu.add(bot_button)
                                    bot.send_message(canal, f'💰️ <b>{nome} fez uma nova compra!</b>\n\n<b>Serviço:</b> Conta SSH VIP {validade} dia(s)\n<b>ID do Cliente:</b> <code>{chat_id}</code>\n<b>ID da Compra:</b> <code>{compra}</code>\n\n<i>⭐️ Cansou de usar VPN de servidores que vivem caindo? Vem para o <b>melhor servidor SSH do Brasil</b>, clica no botão abaixo para comprar o seu login vip de 30 dias. 👇️👇️👇️</i>', reply_markup=menu)
                                except:
                                    print("Erro ao enviar notificação no canal")
                                    continue
                                time.sleep(1)
                                
                            # Atualiza o status da compra com id_compra=1 para 'aprovada'
                            cursor.execute("UPDATE compras SET status = ? WHERE id_compra = ?", ('aprovada', compra))
                            con.commit()
                            print("Status atualizado com sucesso!")

                            # Obter ID do ADMIN
                            cursor.execute('SELECT admin_id FROM bot_config;')
                            resposta = cursor.fetchone()
                            admin_id = resposta[0]  # ID do ADMIN

                            # Notificar ADM
                            bot.send_message(admin_id, f"💰️ <b>Nova compra detectada!</b>\n\n"
                                f"👤 <b>Cliente:</b> {nome} (<code>{chat_id}</code>)\n"
                                f"🆔 <b>ID:</b> <code>{compra}</code>\n"
                                f"👑 <b>Login:</b> <code>{login}</code>\n"
                                f"🔐 <b>Senha:</b> <code>{senha}</code>\n"
                                f"🔑 <b>UUID V2Ray:</b> <code>{v2ray_uuid}</code>\n"
                                f"📱 <b>Limite de dispositivos:</b> {limite}\n"
                                f"📅 <b>Validade:</b> {validade_data}\n", parse_mode="HTML")
                            
                            # Obter porcentagem
                            try:
                                with sqlite3.connect('database.db') as con:
                                    cursor = con.cursor()
                                    cursor.execute('SELECT recompensa FROM bot_config')
                                    porcentagem = cursor.fetchone()[0]
                            except sqlite3.Error as e:
                                print(f"Erro ao consultar o banco de dados: {e}")

                            # Calcular comissão
                            try:
                                valor_pago = int(valor_pago)  # Assegure que valor_pago é um número inteiro
                                comissão = (valor_pago * porcentagem) / 100
                                print(f'A comissão calculada é: {comissão}')
                            except Exception as e:
                                print(f"Erro ao calcular a comissão: {e}")
                            
                            # Notifiação e atualilzação de saldo do afiliado
                            try:
                                with sqlite3.connect('database.db') as con:
                                    cursor = con.cursor()

                                    # Verificar se o usuário tem um afiliado
                                    cursor.execute('SELECT afiliado_id FROM leads WHERE user_id = ?', (chat_id,))
                                    result = cursor.fetchone()
                                    if result and result[0]:
                                        afiliado = result[0]

                                        # Obter saldo atual do afiliado
                                        cursor.execute('SELECT saldo FROM afiliados WHERE chat_id = ?', (afiliado,))
                                        saldo = cursor.fetchone()[0]
                                        
                                        # Atualizar saldo
                                        novo_saldo = int(comissão) + int(saldo)
                                        cursor.execute('UPDATE afiliados SET saldo = ? WHERE chat_id = ?', (novo_saldo, afiliado))
                                        con.commit()
                                        print(f'Novo saldo é: {novo_saldo}')

                                        # Enviar notificação ao afiliado
                                        bot_info = bot.get_me()
                                        bot_username = bot_info.username
                                        bot.send_message(afiliado, f'Um usuário que você indicou acaba de fazer uma compra no bot @{bot_username}\n\n'
                                                                f'<b>Comissão:</b> R$ {comissão}\n'
                                                                f'<b>Novo saldo:</b> R$ {novo_saldo}\n\n'
                                                                f'<b>Para abrir o menu digite /menu</b>')
                            except sqlite3.Error as e:
                                print(f"Erro ao consultar o banco de dados: {e}")
                            except Exception as e:
                                print(f"Ocorreu um erro: {e}")

                    elif status == "cancelled" or status == "refunded":
                        try:
                            cursor.execute("DELETE FROM compras WHERE id_compra = ?", (compra,))
                            con.commit()
                            print(f"Compra {compra} {'cancelada' if status == 'cancelled' else 'reembolsada'}")
                            
                            try:
                                # Deletar a mensagem que contém o QRCode e PIX copia e cola
                                bot.delete_message(chat_id, msg_pix_id)
                            except telebot.apihelper.ApiException as e:
                                print(f"Erro ao deletar a mensagem {msg_pix_id}: {e}")
                                # Não continue ou interrompa o fluxo, só logue o erro

                            # Informar ao cliente
                            if status == "cancelled":
                                bot.send_message(chat_id, '<b>Compra Cancelada!</b>\n\n'
                                                          'Você não efetuou o pagamento no prazo de 30 minutos, então para sua segurança fizemos o cancelamento.\n\n'
                                                          'Envie /menu, crie um novo código PIX e pague no prazo estipulado (30 minutos).')
                            else:
                                bot.send_message(chat_id, '<b>Compra Cancelada!</b>\n\n'
                                                          'Seu pagamento foi recusado ou reembolsado, para informações mais precisas acesse extrato do seu banco. Você pode tentar novamente pagando com a mesma conta ou com uma conta de outro banco (se disponível).\n\n'
                                                          'Envie /menu, crie um novo código PIX e pague no prazo estipulado (30 minutos).')
                        except sqlite3.Error as e:
                            print(f"Erro ao atualizar ou deletar a compra: {e}")
        except sqlite3.Error as e:
            print(f"Erro ao consultar as compras: {e}")
        finally:
            # Pausa em segundos para nova verificação
            time.sleep(2)

# Função para obter o link do aplicativo
def obter_app_link():
    with sqlite3.connect("database.db") as con:
        cursor = con.cursor()
        cursor.execute('SELECT app_link FROM apps')
        dados = cursor.fetchone()
    app = str(dados[0])
    return app