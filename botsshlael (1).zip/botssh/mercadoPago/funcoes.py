import mercadopago
import base64
import sys
from PIL import Image
from io import BytesIO
import sqlite3
import datetime
import os
import time

# ============== Conectar ao banco de dados e obter o token do mercado pago ===================== #
# =============================================================================================== #
with sqlite3.connect('database.db') as con:
    cursor = con.cursor()
    cursor.execute('SELECT token_mp FROM bot_config;')
    dados = cursor.fetchone()
token_mp = str(dados[0])
sdk = mercadopago.SDK(f"{token_mp}")
time.sleep(1)
###################################################################################################

# ================== CRIAR COBRANÇA DO PRODUTO ================== #
#def cobrar(valor, bot, chat_id, limite):
def cobrar(bot, chat_id, client_name, email, logins, validade, preco):
    expire = datetime.datetime.now() + datetime.timedelta(minutes=30)
    expire = expire.strftime("%Y-%m-%dT%H:%M:%S.000-03:00")
    print(f"Expira em {expire}")
    print(email)
    payment_data = {
        "transaction_amount": preco,
        "description": f"SSH VIP - {logins} Login(s) {validade} dias",
        "payment_method_id": 'pix',
        "installments": 1,  # numero de parcelas (NÃO ALTERAR)
        "date_of_expiration": f"{expire}",
        "payer": {
            "email": email
        }
    }

    print("\nEtapa 1, OK\n")

    result = sdk.payment().create(payment_data)
    payment = result["response"]
    print(payment)
    pagamento_id = payment["id"]
    pix_copia_e_cola = payment['point_of_interaction']['transaction_data']['qr_code']
    qr_code = payment['point_of_interaction']['transaction_data']['qr_code_base64']

    print('\nEtapa 2, OK!\n')

    qr_decoded = base64.b64decode(qr_code)
    img = Image.open(BytesIO(qr_decoded))
    msg_pix = bot.send_photo(chat_id, img, caption=f'<b>Valor da cobrança:</b> R${preco},00\n\n<i>Você pode escanear o QRCODE da imagem acima em outro dispositivo para pagar, ou pague com o código do <b>"PIX Copia e Cola"</b> abaixo:</i>\n\n<b>OBS.:</b> Código valido por apenas 30 minutos.\n<b>Clique no código para copiar 👇️👇️</b>\n\n<code>{pix_copia_e_cola}</code>', parse_mode="HTML")
    msg_pix_id = msg_pix.message_id

    try:
        with sqlite3.connect('database.db') as con:
            cursor = con.cursor()

            # Verifica se a coluna 'msg_pix_id' já existe na tabela 'compras'
            cursor.execute("PRAGMA table_info(compras)")
            columns = [column[1] for column in cursor.fetchall()]

            # Se 'msg_pix_id' não estiver na lista de colunas, adiciona a coluna
            if 'msg_pix_id' not in columns:
                cursor.execute("ALTER TABLE compras ADD COLUMN msg_pix_id INTEGER")
                con.commit()
                print("Coluna 'msg_pix_id' adicionada com sucesso")

            # Adiciona as informações na tabela "compras"
            cursor.execute("INSERT INTO compras (user_id, cliente, id_compra, limite, validade, status, msg_pix_id) VALUES (?, ?, ?, ?, ?, ?, ?)", (chat_id, client_name, pagamento_id, logins, validade, 'pendente', msg_pix_id))
            con.commit()
            print("Dados inseridos com sucesso!")
    except sqlite3.Error as e:
        print(f"Erro ao inserir dados: {e}")