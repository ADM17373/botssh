import telebot

# Substitua 'SEU_TOKEN' pelo token do seu bot
TOKEN = '5335702344:AAFHOcR_4Ng-LuyPYYAOaBHATDlaJC2P7b0'

# Criação de uma instância do bot
bot = telebot.TeleBot(TOKEN)

# Manipula a mensagem /start para obter o ID do canal
@bot.message_handler(commands=['start'])
def handle_start(message):
    # Substitua 'NOME_DO_CANAL' pelo nome de usuário do seu canal
    channel_info = bot.get_chat('@oficial_speednet')
    
    # Obtém o ID do canal
    channel_id = channel_info.id
    
    # Envia o ID do canal como mensagem de volta ao usuário
    bot.send_message(message.chat.id, f"ID do Canal: {channel_id}")

# Inicia o bot
bot.polling()