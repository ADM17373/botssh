import sqlite3

novo_id = input("Digite o novo ID do Telegram do administrador: ")
con = sqlite3.connect('database.db')  # Substitua 'database.db' pelo nome do seu arquivo de banco de dados
cursor = con.cursor()
# Execute a consulta SQL UPDATE para atualizar o valor da coluna admin_id
cursor.execute("UPDATE bot_config SET admin_id = ? WHERE 1=1", (novo_id,))  # Use "WHERE 1=1" para atualizar todas as linhas, se necessário
# Confirme as alterações no banco de dados
con.commit()
con.close()  # Feche a conexão com o banco de dados