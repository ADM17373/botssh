import telebot
import sqlite3
import subprocess
import os, sys

# ============== Conectar ao banco de dados, obter o token_bot e o admin_id ===================== #
# =============================================================================================== #

con = sqlite3.connect('database.db')
cursor = con.cursor()
cursor.execute('SELECT bot_token, admin_id FROM bot_config;')
dados = cursor.fetchone()

if dados:
    bot_token = str(dados[0])
    admin_id = str(dados[1])

else:
    print("Nenhum dado encontrado na tabela bot_config.")

cursor.close()
con.close()
###################################################################################################

bot = telebot.TeleBot(bot_token, parse_mode="HTML")

# --- Criar Backup do bot --- #
compress_command = 'zip -r /root/modules.zip /modules'
move_command = 'mv /root/modules.zip /modules/botssh/botssh.bak'
compress_result = subprocess.run(compress_command, shell=True)
if compress_result.returncode == 0:
    subprocess.run(move_command, shell=True)

    # Envia o arquivo para o admininstrador/dono do bot
    print(admin_id)
    bot.send_document(admin_id, open('botssh.bak', 'rb'), caption="<b>Backup de dados do seu Bot</b>\n"
                                                                  "<i><b>Não exclua,</b> pois sem esse arquivo não será possivel restaurar o backup do bot.</i>")

    # Exclui o arquivo do servidor
    os.remove("/modules/botssh/botssh.bak")

else:
    # Informa que não foi possível gerar o Backup
    bot.send_message(admin_id, "Backup do bot Falhou...")
