import telebot
import requests

bot = telebot.TeleBot('5335702344:AAF6NBpi1EKFdDZb90FNZaYyGG4K9BqGsg0')

# Defina a função que será executada quando o usuário clicar no link com o ID do usuário
@bot.message_handler(commands=['start'])
def start(message):
    if message.text == "/start":
        bot.send_message(message.from_user.id, "Olá, seja bem-vindo(a)!")
    else:
        # Extrai o ID do usuário do parâmetro do deeplink
        user_id = message.text.split()[1]
        print(user_id)
        # verifica se o parametro do deeplink é igual ao id do usuário
        if str(user_id) == str(message.from_user.id):
            bot.reply_to(message, f"Bem-vindo ao meu bot, usuário {user_id}")
        else:
            bot.reply_to(message, "Falha na verificação!")

@bot.message_handler(commands=['encurtar'])
def encurtar(message):
    chat_id = str(message.from_user.id)
    base_url = "https://t.me/CobaiaDev_bot?start="
    api = requests.get(f'https://encurta.net/api?api=294ad777b22887f57ce508e7c81d09aaa64749c1&url={base_url}{chat_id}&format=text')
    bot_url = api.text
    bot.send_message(chat_id, f"Seu deeplink: {bot_url}")

# Inicie o loop de atualização do bot
bot.polling()