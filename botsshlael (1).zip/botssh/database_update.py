import sqlite3

def update_database_structure(new_db_filename, current_db_filename):
    # Conectar ao banco de dados atual
    conn_current = sqlite3.connect(current_db_filename)
    cursor_current = conn_current.cursor()

    # Conectar ao banco de dados com a nova estrutura
    conn_new = sqlite3.connect(new_db_filename)
    cursor_new = conn_new.cursor()

    # Obter a lista de tabelas do banco de dados atual
    cursor_current.execute("SELECT name FROM sqlite_master WHERE type='table';")
    current_tables = set(row[0] for row in cursor_current.fetchall())

    # Obter a lista de tabelas do banco de dados com a nova estrutura
    cursor_new.execute("SELECT name FROM sqlite_master WHERE type='table';")
    new_tables = set(row[0] for row in cursor_new.fetchall())

    # Comparar e adicionar novas tabelas
    for table_name in new_tables - current_tables:
        cursor_new.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table_name}';")
        create_table_sql = cursor_new.fetchone()[0]
        cursor_current.execute(create_table_sql)

    # Obter a lista de colunas em cada tabela do banco de dados atual
    current_columns = {}
    for table_name in current_tables:
        cursor_current.execute(f"PRAGMA table_info({table_name});")
        current_columns[table_name] = set(row[1] for row in cursor_current.fetchall())

    # Obter a lista de colunas em cada tabela do banco de dados com a nova estrutura
    new_columns = {}
    for table_name in new_tables:
        cursor_new.execute(f"PRAGMA table_info({table_name});")
        new_columns[table_name] = {row[1]: (row[2], row[4]) for row in cursor_new.fetchall()}

    # Comparar e adicionar novas colunas
    for table_name in new_tables:
        for column_name, (data_type, default_value) in new_columns[table_name].items():
            if column_name not in current_columns.get(table_name, set()):
                alter_sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {data_type}"
                if default_value is not None:
                    alter_sql += f" DEFAULT {default_value}"
                cursor_current.execute(alter_sql)

    # Commit e fechar as conexões
    conn_current.commit()
    conn_current.close()
    conn_new.close()

# Exemplo de uso
update_database_structure("estrutura.db", "database.db")