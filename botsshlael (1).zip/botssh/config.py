import sqlite3
import time

def create_database_with_model_structure(model_db_filename, new_db_filename):
    # Conectar ao banco de dados modelo
    conn_model = sqlite3.connect(model_db_filename)
    cursor_model = conn_model.cursor()

    # Obter a estrutura das tabelas do banco de dados modelo
    cursor_model.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence';")
    table_structures = cursor_model.fetchall()

    # Conectar ao novo banco de dados, que será criado vazio com a mesma estrutura
    conn_new = sqlite3.connect(new_db_filename)
    cursor_new = conn_new.cursor()

    # Criar as tabelas no novo banco de dados usando a estrutura do banco de dados modelo
    for table_structure in table_structures:
        try:
            cursor_new.execute(table_structure[0])
        except sqlite3.OperationalError as e:
            print(f"Erro ao criar tabela: {e}")

    # Fechar as conexões
    conn_model.close()
    conn_new.commit()
    conn_new.close()

# Exemplo de uso
create_database_with_model_structure("./estrutura.db", "./database.db")

print("\n\033[1;34mVamos configurar seu bot agora...\033[0m\n"
      "\033[1;32mPrecisaremos de algumas iformações, digite-as com cuidado!\033[0m \n\n")

token = input("\033[0;36mSe ainda não tem o token do bot, crie aqui: \033[4;36mhttps://t.me/BotFather\033[0m \n"
              "\033[1;33mQual é o token do seu bot?\033[0m \033[0;35mCole e tecle [ENTER]: \033[0m")

token_mp = input("\n\033[1;33mVamos configurar a API de pagamentos do Mercado Pago.\033[0m\n"
                 "\033[0;36mObter/Criar uma nova Aplicação: \033[4;36mhttps://www.mercadopago.com.br/developers/panel\033[0m\n"
                 "\033[0;35mCole seu Access Token do MercadoPago e tecle [ENTER]: \033[0m")

chat_id = input("\n\033[1;33mAgora o seu ID do Telegram.\033[0m\n"
                "\033[0;35mCaso não saiba, você pode obter em nosso grupo.\033[0m\n"
                "\033[0;36mAcesse: \033[4;36mhttps://t.me/SpeedNetPB\033[0m e envie uma mensagem /myinfo no grupo \n"
                "\033[0;35mCole seu ID aqui e tecle [ENTER]: \033[0m")

print(f"\n\033[1;32mO token do seu bot é:\033[0m {token}\n"
      f"\033[1;32mE o Access Token:\033[0m {token_mp}\n"
      f"\033[1;32mSeu ID:\033[0m {chat_id}\n\n"
      f"\033[1;33mOK! Prosseguindo com a instalação...\033[0m\n\n")
time.sleep(2)

# Daqui pra baixo para inserir ou atualizar a configuração do bot...
con = sqlite3.connect('database.db')
cursor = con.cursor()

# Como 'id' é uma chave primária autoincrementada, você pode definir um valor fixo que será sempre usado
# para a única linha da tabela. Por exemplo, '1'.
id_da_config = 1

# Inserir ou substituir token do bot e id do admin
# A instrução INSERT OR REPLACE irá inserir uma nova linha se não existir uma linha com o mesmo 'id'
# ou substituirá a linha existente se o 'id' já estiver na tabela
cursor.execute("INSERT OR REPLACE INTO bot_config (id, token_mp, bot_token, admin_id) VALUES (?, ?, ?, ?)", (id_da_config, token_mp, token, chat_id))

con.commit()
con.close()