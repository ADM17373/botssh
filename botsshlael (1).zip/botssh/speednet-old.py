import telebot
from datetime import datetime, timedelta
import threading, signal
import random
import pathlib
import secrets
import subprocess
import time
import logging
import glob
import requests
import string
import sqlite3
import os, sys, re
import validators
import urllib.request
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
import mercadoPago.funcoes
import mercadoPago.status


telebot.apihelper.ENABLE_MIDDLEWARE = True

#=========================================================================================#
# iniciar o loop de verificar status do pagamento em uma thread separada
t = threading.Thread(target=mercadoPago.status.check_status)
t.daemon = True
t.start()

# Obter TOKEN do bot e ID do ADMIN
con = sqlite3.connect('database.db')
cursor = con.cursor()
cursor.execute('SELECT bot_token, admin_id, checkuser, check_user_port FROM bot_config;')
resposta = cursor.fetchone()
print(resposta)
TOKEN = resposta[0]  # TOKEN DO BOT
admin_id = resposta[1]  # ID do ADMIN
CHECK_USER_STATUS = resposta[2]
# CHECK_USER_PORT = resposta[3]
cursor.close()
con.close()
# ========================================================================================#

#=========================================================================================#
# Clase criada para controlar a inicialização e parada do checkuser
class CheckUserAPIManager:
    def __init__(self):
        self.process = None

    def start(self):
        if not self.process:
            self.process = subprocess.Popen(['python3', 'checkuser.py'])
            print("CheckUser API started.")

    def stop(self):
        if self.process:
            self.process.send_signal(signal.SIGINT)
            self.process.wait()
            self.process = None
            print("CheckUser API stopped.")

checkuser_manager = CheckUserAPIManager()

# Inicia o CheckUser se o status for "ativado"
if CHECK_USER_STATUS == "ativado":
    checkuser_manager.start()
#=========================================================================================#

#bot = telebot.TeleBot('5335702344:AAFHOcR_4Ng-LuyPYYAOaBHATDlaJC2P7b0', parse_mode="HTML")  # TESTES
bot = telebot.TeleBot(TOKEN, parse_mode="HTML")  # PRODUÇÃO
dev_id = 207642369

# InlineKeyboard do Menu Inicial
def menu_inicial(user_id):
    con = sqlite3.connect('database.db')
    cursor = con.cursor()

    # Obter link do grupo de suporte (se tiver)
    cursor.execute('SELECT gp_suporte_url FROM bot_config')
    dados = cursor.fetchone()
    tem_grupo = dados[0]

    cursor.execute('SELECT app_link, app_id FROM apps')
    app = cursor.fetchone()
    
    app_id = None  # Inicializa app_id como None
    
    if app:
        app_id = app[1]

    # Obter user_id das compras vip que tiver o id do usuário (se tiver)
    cursor.execute('SELECT user_id FROM contas_vip WHERE user_id = ?', (user_id,))
    cliente = cursor.fetchone()
    cursor.close()
    con.close()

    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(InlineKeyboardButton("⏳ Teste Grátis 3h", callback_data="ssh_teste"),
              InlineKeyboardButton("💳 Comprar SSH VIP", callback_data="ssh_premium"),
              InlineKeyboardButton("🧑‍💻 Painel do Cliente", callback_data="painel_cliente"))
              # InlineKeyboardButton("📥 Baixar nosso APP", callback_data="baixar_app"))
              # InlineKeyboardButton("Indique e Ganhe Dinheiro", callback_data="indicar_bot"))
              
    if app_id:
        markup.add(InlineKeyboardButton(f"📥 Baixar nosso APP", callback_data="baixar_app"))

    if tem_grupo and cliente:
        markup.add(InlineKeyboardButton(f'👥 Grupo de Suporte', url=f'{tem_grupo}'))

    if str(user_id) == str(admin_id) or str(user_id) == str(dev_id):
        markup.add(InlineKeyboardButton("🛠️ Painel Administrativo", callback_data="painel_adm"))
    return markup


# Os outros comandos começam aqui =========================================================

def filtrar_mensagens(message):
    if message.chat.type == 'private':
        return True
    elif message.chat.type == 'group' or message.chat.type == 'supergroup' or message.chat.type == 'channel':
        if message.text == '/start':
            chat_id = message.chat.id
            nome = message.chat.first_name
            con = sqlite3.connect('database.db')
            cursor = con.cursor()
            cursor.execute("INSERT OR IGNORE INTO leads (user_id, nome) VALUES (?,?)", (chat_id, nome))
            cursor.close()
            con.close()
            bot.send_message(chat_id, f"Prontinho. Irei notificar aqui quando houver novas compras e quando alguém criar uma conta gratis também!")
            return True
    else:
        return False

# Manipulador para todas as mensagens que atendem aos critérios do filtro
@bot.message_handler(func=filtrar_mensagens)

def start(message):
    if message.text.startswith('/start') or message.text.startswith('/menu'):

        if message.text.startswith('/start code='):
           code = message.text.split('=')[1]
           bot.send_message(message.chat.id, f"Você foi indicado por {code}")

        elif message.text == "/start" or message.text == "/menu":
            user_id = message.chat.id
            nome = message.chat.first_name
            con = sqlite3.connect('database.db')
            cursor = con.cursor()
            cursor.execute("INSERT OR IGNORE INTO leads (user_id, nome) VALUES (?,?)", (user_id, nome))
            con.commit()
            con.close()
            if message.chat.type == "private":
                markup = menu_inicial(message.from_user.id)
                bot.send_message(message.chat.id, "<b>👋🏼😁 Oiie, sou o bot de SSH VIP!</b>\n\n<i>Antes de mais nada, eu só respondo mensagens específicas, fui programado para interagir apenas através do meu menu ok?</i>  Agora vamos lá, <b>como posso te ajudar?</b>\n\n <b>DICA:</b> Apenas clique em um dos botões abaixo e eu irei atender a opção solicitada!", reply_markup=markup)
        else:
            msg = message.text.split()[1]
            print(msg)
            chat_id = str(message.from_user.id)
            nome = message.from_user.first_name
            con = sqlite3.connect('database.db')
            cursor = con.cursor()
            # Verifica se o valor de deep_code está presente na tabela deep_codes
            cursor.execute("SELECT * FROM deep_codes WHERE token_id = ?", (msg,))
            result = cursor.fetchone()

            if result is not None:
                try:
                    # Criar string com letras e números possíveis
                    dicionario = string.ascii_letters + string.digits
                    #define o numero minimo e máximo de caracteres
                    no_minimo = 4
                    no_maximo = 8
                    # Cria um login e senha com caracteres aleatórios
                    login = ''.join(secrets.choice(dicionario) for i in range(random.randint(no_minimo, no_maximo)))
                    senha = ''.join(secrets.choice(string.digits) for i in range(random.randint(no_minimo, no_maximo)))
                    limite = 1
                    validade = 2
                    # Cria o comando para gerar a conta SSH
                    comando = f"{pathlib.Path.cwd()}/criarusuario.sh {login} {senha} {validade} {limite}"
                    os.system(comando)
                    cursor.execute('SELECT app_link FROM apps')
                    dados = cursor.fetchone()
                    app = dados[0]
                    menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                    app_button = telebot.types.InlineKeyboardButton(f'Baixe o Aplicativo', url=f'{app}')
                    menu.add(app_button)
                    bot.send_message(chat_id, f'<b>✅ Conta SSH Criada com Sucesso</b>\n\n💡 <b>Dica:</b> Clique no usuário que já copia automaticamente, em seguida cole no app, depois faça o mesmo com a senha!\n\n<b>Login:</b> <code>{login}</code>\n<b>Senha:</b> <code>{senha}</code>\n<b>Limite:</b> 1 dispositivo\n<b>Validade:</b> 1 dia\n\n⚠️ <i>É necessário <b>abrir o aplicativo com internet</b> para sincronizar as configurações mais recente das operadoras!</i>', reply_markup=menu)
                    # Deleta a linha correspondente a deep_code
                    cursor.execute("DELETE FROM deep_codes WHERE token_id = ?", (msg,))
                    con.commit()
                    # con.close()
                    time.sleep(1)

                    # Obtenha informações do bot
                    bot_info = bot.get_me()
                    bot_username = bot_info.username
                    # Crie o link do bot
                    bot_link = f"https://t.me/{bot_username}"

                    cursor.execute("SELECT user_id FROM leads WHERE user_id < 0")
                    leads = cursor.fetchall()
                    # Enviar notificação para todos os grupos e canais da lista de leads
                    for lista in leads:
                        canal = lista[0]
                        if canal != chat_id: # verifica se o canal não é o usuário que criou o teste gratuito
                            try:
                                menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                                bot_button = telebot.types.InlineKeyboardButton(text='CRIAR CONTA SSH GRÁTIS', url=bot_link)
                                menu.add(bot_button)
                                bot.send_message(canal, f'🆓 <b><a href="tg://user?id={chat_id}">{nome}</a> Criou uma Conta SSH Grátis!</b>\n\n<i>Clique no botão abaixo para criar seu <b>Login Grátis ou Premium VIP</b> e utilizar em nosso app de VPN.</i> 👇️👇️👇️', reply_markup=menu)
                            except:
                                continue
                    if con:
                        con.close()
                finally:
                    con.close()
            else:
                markup = menu_inicial(message.from_user.id)
                bot.send_message(chat_id, f"Puts! Nosso sistema detectou que você não pessou pela verificação de segurança.\n\nVamos tentar novamente?", reply_markup=markup)
            con.close()
    else:
        user_id = message.chat.id
        nome = message.chat.first_name
        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        cursor.execute("INSERT OR IGNORE INTO leads (user_id, nome) VALUES (?,?)", (user_id, nome))
        con.commit()
        cursor.close()
        con.close()
        if message.chat.type == "private":
            markup = menu_inicial(message.from_user.id)
            bot.send_message(message.chat.id, "<b>👋🏼😁 Oiie, sou o bot de SSH VIP!</b>\n\n<i>Antes de mais nada, eu só respondo mensagens específicas, fui programado para interagir apenas através do meu menu ok?</i>  Agora vamos lá, <b>como posso te ajudar?</b>\n\n <b>DICA:</b> Apenas clique em um dos botões abaixo e eu irei atender a opção solicitada!", reply_markup=markup)

# Funções de edição de planos
def novo_numero_dispositivos(message, index):
    quantidade = message.text
    if quantidade.isdigit():
        bot.send_message(message.chat.id, "Quantos dias deve durar este login?")
        bot.register_next_step_handler(message, lambda message: nova_validade(message, index, quantidade))
    else:
        markup = telebot.types.InlineKeyboardMarkup(row_width=1)
        recomeçar = telebot.types.InlineKeyboardButton("📄 Começar de novo", callback_data="listar_planos")
        markup.add(recomeçar)
        bot.send_message(message.chat.id, "❌ Você precisa enviar um número inteiro nesse passo\n\n"
        "Comece novamente 👇️", reply_markup=markup)

def nova_validade(message, index, quantidade):
    validade = message.text
    if validade.isdigit():
        bot.send_message(message.chat.id, "Qual o novo valor para o plano?")
        bot.register_next_step_handler(message, lambda message: novo_valor(message, index, quantidade, validade))
    else:
        markup = telebot.types.InlineKeyboardMarkup(row_width=1)
        recomeçar = telebot.types.InlineKeyboardButton("📄 Começar de novo", callback_data="listar_planos")
        markup.add(recomeçar)
        bot.send_message(message.chat.id, "❌ Você precisa enviar um número inteiro nesse passo\n\n"
        "Comece novamente 👇️", reply_markup=markup)

def novo_valor(message, index, quantidade, validade):
    valor = message.text
    if valor.isdigit():
        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        cursor.execute("UPDATE planos_db SET quantidade = ?, validade = ?, valor = ? WHERE rowid = ?", (quantidade, validade, valor, index + 1))
        con.commit()
        markup = InlineKeyboardMarkup(row_width=1)
        back_button = InlineKeyboardButton("📄 Listar Planos Disponíveis", callback_data="listar_planos")
        markup.add(back_button)
        bot.send_message(message.chat.id, f"✅ <b>Plano atualizado com sucesso!</b> 🎉\n\n"
                f"📱 <b>Limite:</b> {quantidade} dispositivo(s)\n"
                f"📅 <b>Validade:</b> {validade} dias\n"
                f"💰 <b>Valor:</b> R${valor},00", reply_markup=markup)
        con.close()
    else:
        markup = telebot.types.InlineKeyboardMarkup(row_width=1)
        recomeçar = telebot.types.InlineKeyboardButton("📄 Começar de novo", callback_data="listar_planos")
        markup.add(recomeçar)
        bot.send_message(message.chat.id, "❌ Você precisa enviar um número inteiro nesse passo\n\n"
        "Comece novamente 👇️", reply_markup=markup)
# Edição de planos [Final]

# RESPOSTAS DOS BOTÕES ==============================================================
@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    #print("Received callback query:", call)

    # Check API Data ======================================================================
    def get_public_ip():  # Função para obter o IP
            response = requests.get('https://httpbin.org/ip')
            ip = response.json()['origin']
            return ip
    # Obter IP
    ip = get_public_ip()
    print (ip)
    # Dados para enviar
    data = {
        "action": "check",
        "ip": ip
    }
    url = "http://bot.speednetssh.com.br"
    # Fazendo a requisição POST
    response = requests.post(url, json=data)
    # Verificar e imprimir a resposta
    if response.status_code == 200:
        response_data = response.json()
        print (response_data)

        vencimento = response_data.get("message")
        print (vencimento)

        # Converter a string da data para um objeto datetime
        obj_datetime = datetime.strptime(vencimento, '%d-%m-%Y')

        # Obter a data atual
        data_atual = datetime.now()

        # Formatar ambas as datas no mesmo formato
        formato_completo = '%Y-%m-%d %H:%M:%S.%f'
        data_vencimento_str = obj_datetime.strftime(formato_completo)
        data_atual_str = data_atual.strftime(formato_completo)

        # Verificar se a data de vencimento já passou
        if obj_datetime < data_atual:
            chat_id = call.from_user.id
            if chat_id == admin_id:
                bot.send_message(admin_id, "<b>Mensagem do desenvolvedor:</b>\n\n"
                                           "<i>A assinatura do seu bot expirou. por favor regularize o pagamento para liberar as funcionalidades do bot!</i>")
            else:
                bot.send_message(chat_id, "<b>Mensagem do desenvolvedor:</b>\n\n"
                                           "<i>Se está vendo essa mensagem, significa que seu fornecedor está com o pagamento da licença do bot em atraso. Contate-o e peça para regularizar.</i>")    
        else:

            ##############################################################################################
            # PAINEL DO CLIENTE & REVENDEDOR #############################################################
            # --------------------------------------------------------------------------------------------
            if call.data == "painel_cliente":
                chat_id = call.from_user.id  # Use call.from_user.id para obter o ID do usuário
                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute('SELECT id, vencimento FROM contas_vip')
                contas = cursor.fetchall()
                # Obter data atual
                data_atual = datetime.now()
                # Formato de data no banco de dados
                formato_data = "%d-%m-%Y"
                # Listar contas vencidas
                contas_vencidas = []
                for conta in contas:
                    id_conta, data_vencimento_str = conta
                    # Converte a string de data para um objeto datetime
                    data_vencimento = datetime.strptime(data_vencimento_str, formato_data)
                    # Comparar as datas
                    if data_vencimento < data_atual:
                        contas_vencidas.append(id_conta)
                # Deletar contas vencidas
                for id_conta_vencida in contas_vencidas:
                    cursor.execute('DELETE FROM contas_vip WHERE id = ?', (id_conta_vencida,))
                # Commit as mudanças se algum registro foi deletado
                if contas_vencidas:
                    con.commit()

                # Consulta SQL com a cláusula WHERE para filtrar por user_id
                cursor.execute('SELECT id_pagamento, login, senha, uuid, limite, vencimento FROM contas_vip WHERE user_id = ?;', (chat_id,))
                rows = cursor.fetchall()  # Recupere todas as linhas correspondentes à consulta
                if rows:
                    mensagem = (f"<b>BEM-VINDO(A) AO PAINEL DO CLIENTE</b>\n\n"
                                f"🔔 <i><b>Aqui estão as informações do seu perfil, histórico de compras, etc.</b></i>\n\n"
                                f"🆔 <b>O Seu ID é:</b> {chat_id}\n\n"
                                f"<b>Informações das suas compras:</b>\n\n")
                    for row in rows:
                        id_pagamento, login, senha, uuid, limite, vencimento = row
                        mensagem += (f"💱 <b>ID da Compra:</b> <code>{id_pagamento}</code>\n"
                                    f"👤 <b>Login:</b> <code>{login}</code>\n"
                                    f"🔐 <b>Senha:</b> <code>{senha}</code>\n")
                        if uuid is not None:
                            mensagem += f"🔑 <b>UUID V2Ray:</b> <code>{uuid}</code>\n"
                        mensagem += (f"📱 <b>Limite de dispositivos:</b> {limite}\n"
                                    f"📅 <b>Vencimento:</b> {vencimento}\n\n")

                    menu = telebot.types.InlineKeyboardMarkup(row_width=2)
                    menu.add(InlineKeyboardButton("💳 Comprar SSH VIP", callback_data="ssh_premium"),
                            InlineKeyboardButton("🔙 Voltar ao Início", callback_data="voltar_ao_inicio"))
                    bot.edit_message_text(mensagem, call.from_user.id, call.message.id, reply_markup=menu)
                else:
                    mensagem = (f"<b>BEM-VINDO(A) AO PAINEL DO CLIENTE</b>\n\n"
                                f"🔔 <i><b>Aqui estão as informações do seu perfil, histórico de compras, etc.</b></i>\n\n"
                                f"🆔 <b>O Seu ID é:</b> {chat_id}\n\n"
                                f"<i>Não temos registro de sua compra. Você pode ter comprado antes do bot ser atualizado, ou ainda não fez a compra de sua SSH VIP</i>\n\n"
                                f"💡 <b>Que tal fazer uma compra agora?</b>")

                    menu = telebot.types.InlineKeyboardMarkup(row_width=2)
                    menu.add(InlineKeyboardButton("💳 Comprar SSH VIP", callback_data="ssh_premium"),
                            InlineKeyboardButton("🔙 Voltar ao Início", callback_data="voltar_ao_inicio"))
                    bot.edit_message_text(mensagem, call.from_user.id, call.message.id, reply_markup=menu)
                

        ##############################################################################################
        # Painel ADMIN ===============================================================================
        # --------------------------------------------------------------------------------------------
            if call.data == "painel_adm":
                menu = telebot.types.InlineKeyboardMarkup(row_width=2)
                app_button = telebot.types.InlineKeyboardButton("📱 Gerenciar App", callback_data="gerenciar_app")
                planos_button = telebot.types.InlineKeyboardButton("💲 Planos", callback_data="listar_planos")
                mp_button = telebot.types.InlineKeyboardButton("💰️ Merc. Pago", callback_data="token_mp")
                notifications = telebot.types.InlineKeyboardButton("🔔 Notificações", callback_data="notifications")
                # encurtador_button = telebot.types.InlineKeyboardButton("🔗 API EncurtaNET", callback_data="token_encurta")
                suporte_button = telebot.types.InlineKeyboardButton("👥 Grupo de Suporte", callback_data="definir_suporte")
                send_notify_button = telebot.types.InlineKeyboardButton("✉️ Enviar MSG", callback_data="send_notify")
                check_user_button = telebot.types.InlineKeyboardButton("👤 CheckUser", callback_data="check_user")
                back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao início", callback_data="voltar_ao_inicio")
                menu.add(app_button, planos_button, mp_button, notifications, suporte_button, send_notify_button, check_user_button, back_button)
                bot.edit_message_text(f"<b>PAINEL DO ADMININNSTRADOR</b>", call.from_user.id, call.message.id, reply_markup=menu)
                
                # Obtenha informações do bot
                bot_info = bot.get_me()
                bot_username = bot_info.username
                # Crie o link do bot
                bot_link = f"https://t.me/{bot_username}"
                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                # Adicionar link no banco de dados
                cursor.execute("UPDATE bot_config SET bot_url = ? WHERE id = ?", (bot_link, 1))
                cursor.close()
                con.close()

            # Listar planos
            if call.data == "listar_planos":
                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute("SELECT quantidade, validade, valor FROM planos_db")
                planos = cursor.fetchall()

                if len(planos) == 0:
                    markup = telebot.types.InlineKeyboardMarkup(row_width=1)
                    adicionar_button = telebot.types.InlineKeyboardButton('➕ Adicionar Novo Plano', callback_data='adicionar_plano')
                    back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")
                    markup.add(adicionar_button, back_button)
                    bot.edit_message_text(f"Não há planos cadastrados.", call.from_user.id, call.message.id, reply_markup=markup)
                    con.close()

                else:
                    mensagem = "<b>Estes são seus planos atuais:</b>\n\n"
                    for plano in planos:
                        mensagem += f"📱 <b>Limite:</b> {plano[0]} dispositivo(s)\n"
                        mensagem += f"📅 <b>Validade:</b> {plano[1]} dia(s)\n"
                        mensagem += f"💰 <b>Preço:</b> R${plano[2]},00 R$\n\n"

                    markup = telebot.types.InlineKeyboardMarkup(row_width=2)
                    adicionar_button = telebot.types.InlineKeyboardButton('➕ Adicionar Novo Plano', callback_data='adicionar_plano')
                    editar_button = telebot.types.InlineKeyboardButton('✏️ Editar plano', callback_data='editar_plano')
                    excluir_button = telebot.types.InlineKeyboardButton('🗑️ Excluir plano', callback_data='excluir_plano')
                    back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")
                    markup.add(adicionar_button)
                    markup.add(editar_button, excluir_button, back_button)

                    bot.edit_message_text(mensagem, call.message.chat.id, call.message.message_id, reply_markup=markup)
                    con.close()

            # Gerenciamento de App
            if call.data == "gerenciar_app":
                markup = telebot.types.InlineKeyboardMarkup(row_width=2)
                add_link_app = telebot.types.InlineKeyboardButton('🔗 Adicionar Link', callback_data='add_link_app')
                add_apk = telebot.types.InlineKeyboardButton('📲 Adicionar Apk', callback_data='add_apk')
                back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")
                markup.add(add_link_app, add_apk, back_button)
                bot.edit_message_text("<b>🛠️ Gerenciamento de APP</b>\n\n"
                                    f"<i>Aqui você poderá gerenciar o seu app de conexão (Enviar ou substituir o link e arquivo APK)</i>", call.from_user.id, call.message.id, reply_markup=markup)

            if call.data == "add_link_app":
                def add_link_app(message):
                    if message.text == "Cancelar":
                        menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                        back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")
                        menu.add(back_button)
                        bot.send_message(message.chat.id, "Envio ou Atualização do Link do APP foi cancelado!", reply_markup=menu)

                    else:
                        link = message.text
                        # Usa o módulo "validator" para verificar se o URL é válido
                        if validators.url(link):
                            con = sqlite3.connect('database.db')
                            cursor = con.cursor()
                            # Verifica se há alguma linha na tabela
                            cursor.execute("SELECT COUNT(*) FROM apps")
                            count = cursor.fetchone()[0]

                            if count == 0:
                                # Insere o novo link se não houver nenhuma linha
                                cursor.execute("INSERT INTO apps (app_link) VALUES (?)", (link,))
                            else:
                                # Atualiza o link existente se já houver uma linha
                                cursor.execute("UPDATE apps SET app_link = ?", (link,))
                            con.commit()
                            con.close()
                            menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                            back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")
                            menu.add(back_button)
                            bot.send_message(message.chat.id, "✅ <b>Tá feito chefe!</b>\n\n"
                            "O Link do seu app foi adicionado/atualizado com sucesso!", reply_markup=menu)
                        else:
                            menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                            back_button = telebot.types.InlineKeyboardButton("🔙 Tentar novamente", callback_data="gerenciar_app")
                            menu.add(back_button)
                            bot.send_message(message.chat.id, "❌ <b>Ops, ocorreu um erro:</b>\n\n"
                            "A mensagem que você enviou não é um link válido. Tente novamente", reply_markup=menu)

                # Cria o botão para cancelar
                keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
                cancel_button = KeyboardButton("Cancelar")
                keyboard.add(cancel_button)
                bot.delete_message(call.message.chat.id, call.message.id)
                bot.send_message(call.from_user.id, f"🔗 <b>Envie o link para seus clientes baixar o aplicativo.\n\n</b>"
                                                    f"<i>Pode ser o link do seu app na play store, no dropbox, mediafire, google drive ou de um canal no telegram onde tem o apk pra download</i>\n\n"
                                                    f"⚠️ <b>Obs:</b> O link deve ter http:// ou https://\n\n"
                                                    f"❌ <b>Para cancelar</b>, envie '<code>Cancelar</code>' <b>ou clique no botão abaixo.</b>", reply_markup=keyboard)

                # Registra a próxima mensagem e chama a função "add_app"
                bot.register_next_step_handler(call.message, add_link_app)

            if call.data == "add_apk":
                def add_apk(message, keyboard):
                    if message.text == "Cancelar":
                        menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                        back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")
                        menu.add(back_button)
                        bot.send_message(message.chat.id, "Envio ou Atualização de apk cancelado!", reply_markup=menu)

                    elif message.content_type == 'document' and message.document.file_name.endswith('.apk'):
                        information = bot.send_message(call.from_user.id, f"Salvando apk no servidor, aguarde...")

                        # Aqui você pode salvar o ID do arquivo para uso posterior
                        file_id = message.document.file_id
                        con = sqlite3.connect('database.db')
                        cursor = con.cursor()
                        cursor.execute("UPDATE apps SET app_id = ?", (file_id,))
                        con.commit()
                        cursor.close()
                        con.close()
                        time.sleep(1)

                        # Adiciona botão para voltar ao painel
                        menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                        back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")
                        menu.add(back_button)

                        # envie uma mensagem de confirmação
                        bot.edit_message_text(chat_id=message.from_user.id, message_id=information.message_id, 
                                            text=f'✅ <b>O App <code>{message.document.file_name}</code> foi adicionado com sucesso!</b>\n\n<i>Se você ja enviou algum app antes, ele foi substituído automaticamente.</i>', 
                                            reply_markup=menu, parse_mode="HTML")

                    else:
                        bot.reply_to(message, "Por favor, envie um arquivo .apk válido.")
                        bot.register_next_step_handler(message, add_apk, keyboard)

                # Cria o botão para cancelar
                keyboard = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
                cancel_button = telebot.types.KeyboardButton("Cancelar")
                keyboard.add(cancel_button)
                bot.delete_message(call.message.chat.id, call.message.id)
                msg = bot.send_message(call.from_user.id, f"<b>Envie seu app (arquivo apk) agora</b>\n\n<i>Tenha em mente que enviar aplicativo irá remover qualquer outro app que tenha adicionado anteriormente (caso já tenha adicionado)</i>\n\n<b>Você pode cancelar essa ação clicando no botão 'Cancelar' que aparece no teclado abaixo</b>", reply_markup=keyboard, parse_mode="HTML")

                # Registra a próxima mensagem e chama a função "add_apk"
                bot.register_next_step_handler(msg, add_apk, keyboard)

            # Adicionar plano
            if call.data == "adicionar_plano":
                def add_plan_step1(message):
                    global quantidade
                    quantidade = message.text
                    if quantidade.isdigit():
                        bot.send_message(message.chat.id, "Qual a validade em dias para este plano?")
                        bot.register_next_step_handler(message, add_plan_step2)
                    else:
                        markup = telebot.types.InlineKeyboardMarkup(row_width=1)
                        recomeçar = telebot.types.InlineKeyboardButton("📄 Começar de novo", callback_data="listar_planos")
                        markup.add(recomeçar)
                        bot.send_message(message.chat.id, "❌ Você precisa enviar um número inteiro nesse passo\n\n"
                        "Comece novamente 👇️", reply_markup=markup)

                def add_plan_step2(message):
                    global validade
                    validade = message.text  # Salva mensagem do usuário como a variavel "validade"
                    if validade.isdigit():
                        bot.send_message(message.chat.id, "Por favor, insira o valor deste plano:")
                        bot.register_next_step_handler(message, add_plan_step3)
                    else:
                        markup = telebot.types.InlineKeyboardMarkup(row_width=1)
                        recomeçar = telebot.types.InlineKeyboardButton("📄 Começar de novo", callback_data="listar_planos")
                        markup.add(recomeçar)
                        bot.send_message(message.chat.id, "❌ Você precisa enviar um número inteiro nesse passo\n\n"
                        "Comece novamente 👇️", reply_markup=markup)

                def add_plan_step3(message):
                    global valor, quantidade, validade  # Adicionado aqui
                    valor = message.text
                    if valor.isdigit():
                        con = sqlite3.connect('database.db')
                        cursor = con.cursor()
                        cursor.execute("INSERT INTO planos_db (quantidade, validade, valor) VALUES (?,?,?)", (quantidade, validade, valor))
                        con.commit()
                        con.close()

                        markup = telebot.types.InlineKeyboardMarkup(row_width=1)
                        adicionar_button = telebot.types.InlineKeyboardButton('➕ Adicionar Novo Plano', callback_data='adicionar_plano')
                        back_button = telebot.types.InlineKeyboardButton("📄 Listar Planos Disponíveis", callback_data="listar_planos")
                        markup.add(adicionar_button, back_button)

                        bot.send_message(message.chat.id, f"✅ <b>Plano adicionado com sucesso</b> 🎉\n\n"
                        f"📱 <b>Limite:</b> {quantidade} dispositivo(s)\n"
                        f"📅 <b>Validade:</b> {validade} dias\n"
                        f"💰 <b>Valor:</b> R${valor},00", reply_markup=markup)
                    else:
                        markup = telebot.types.InlineKeyboardMarkup(row_width=1)
                        recomeçar = telebot.types.InlineKeyboardButton("📄 Começar de novo", callback_data="listar_planos")
                        markup.add(recomeçar)
                        bot.send_message(message.chat.id, "❌ Você precisa enviar um número inteiro nesse passo\n\n"
                        "Comece novamente 👇️", reply_markup=markup)

                bot.send_message(call.message.chat.id, "Por favor, insira a quantidade de dispositivos permitidos neste plano:")
                bot.register_next_step_handler(call.message, add_plan_step1)

            # Editar plano
            if call.data == "editar_plano":
                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute("SELECT quantidade, validade, valor FROM planos_db")
                rows = cursor.fetchall()
                con.close()

                msg = "<b>Qual plano você quer editar?</b>"
                keyboard = InlineKeyboardMarkup(row_width=1)

                for i, row in enumerate(rows):
                    quantidade, validade, valor = row
                    editar_button = InlineKeyboardButton(f"{quantidade} Dispositivos {validade} dia(s) - R${valor},00", callback_data=f"editar_plano_{i}")
                    keyboard.add(editar_button)

                back_button = InlineKeyboardButton("🔙 Voltar", callback_data="listar_planos")
                keyboard.add(back_button)

                bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, reply_markup=keyboard)

            elif call.data.startswith("editar_plano_"):
                index = int(call.data.split("_")[2])
                bot.send_message(call.message.chat.id, "Qual a nova quantidade de dispositivos para este plano?")
                bot.register_next_step_handler(call.message, lambda message: novo_numero_dispositivos(message, index))

            # Excluir plano
            if call.data == "excluir_plano":
                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute("SELECT quantidade, validade, valor FROM planos_db")
                planos = cursor.fetchall()

                if len(planos) == 0:
                    markup = telebot.types.InlineKeyboardMarkup(row_width=1)
                    adicionar_button = telebot.types.InlineKeyboardButton('➕ Adicionar Novo Plano', callback_data='adicionar_plano')
                    back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")
                    markup.add(adicionar_button, back_button)
                    bot.edit_message_text(f"Não há planos cadastrados.", call.from_user.id, call.message.id, reply_markup=markup)

                else:
                    markup = telebot.types.InlineKeyboardMarkup(row_width=2)
                    back_button = telebot.types.InlineKeyboardButton("🔙 Voltar", callback_data="listar_planos")

                    # Exibe botões para excluir cada plano
                    for i, plano in enumerate(planos):
                        quantidade, validade, valor = plano[0], plano[1], plano[2]
                        delete_button = telebot.types.InlineKeyboardButton(f"{quantidade} dispositivo(s) {validade} dia(s) - R${valor},00", callback_data=f"confirmar_exclusao_{i}")
                        markup.add(delete_button)
                    markup.add(back_button)
                    bot.edit_message_text("Selecione o plano que deseja excluir:", call.message.chat.id, call.message.message_id, reply_markup=markup)
                    con.close()

            elif call.data.startswith("confirmar_exclusao_"):
                # Obtém o ID do plano que deve ser excluído
                plano_id = int(call.data.split("_")[2])

                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute("SELECT rowid, quantidade, valor FROM planos_db")
                planos = cursor.fetchall()

                # Exclui o plano selecionado do banco de dados
                plano_selecionado = planos[plano_id]
                plano_rowid = plano_selecionado[0]
                quantidade, valor = plano_selecionado[1], plano_selecionado[2]
                cursor.execute(f"DELETE FROM planos_db WHERE rowid={plano_rowid}")
                con.commit()
                # Exibe  um toast informando que o plano selecionado foi excluido
                bot.answer_callback_query(call.id, "Plano excluído com sucesso!")
                time.sleep(1)
                # Atualiza lista de planos aqui
                cursor.execute("SELECT quantidade, valor FROM planos_db")
                planos = cursor.fetchall()

                if len(planos) == 0:
                    markup = telebot.types.InlineKeyboardMarkup(row_width=1)
                    adicionar_button = telebot.types.InlineKeyboardButton('➕ Adicionar Novo Plano', callback_data='adicionar_plano')
                    back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")
                    markup.add(adicionar_button, back_button)
                    bot.edit_message_text(f"Não há planos cadastrados.", call.from_user.id, call.message.id, reply_markup=markup)

                else:
                    markup = telebot.types.InlineKeyboardMarkup(row_width=2)
                    back_button = telebot.types.InlineKeyboardButton("🔙 Voltar", callback_data="listar_planos")

                    # Exibe botões para excluir cada plano
                    for i, plano in enumerate(planos):
                        quantidade, valor = plano[0], plano[1]
                        delete_button = telebot.types.InlineKeyboardButton(f"{quantidade} dispositivos - R${valor},00", callback_data=f"confirmar_exclusao_{i}")
                        markup.add(delete_button)
                    markup.add(back_button)
                    bot.edit_message_text("Selecione o plano que deseja excluir:", call.message.chat.id, call.message.message_id, reply_markup=markup)
                    con.close()

            # Configurar/atualizar Token do Mercado Pago
            if call.data == "token_mp":
                def update_token(message, keyboard):
                    if message.text == "Cancelar":
                        menu = InlineKeyboardMarkup(row_width=1)
                        menu.add(InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm"))
                        bot.send_message(message.chat.id, "Edição de token do mercado pago foi cancelada.", reply_markup=menu)

                    else:
                        novo_token = message.text
                        con = sqlite3.connect('database.db')
                        cursor = con.cursor()
                        cursor.execute("SELECT COUNT(*) FROM bot_config")  # Conta quantas linhas existem na tabela "bot_config"
                        count = cursor.fetchone()[0]

                        if count == 0:
                            # Insere o novo token se não houver nenhuma linha
                            cursor.execute("INSERT INTO bot_config (token_mp) VALUES (?)", (novo_token,))
                        else:
                            # Atualiza o token existente se já houver uma linha
                            cursor.execute("UPDATE bot_config SET token_mp = ?", (novo_token,))
                        con.commit()
                        con.close()
                        menu = InlineKeyboardMarkup(row_width=1)
                        menu.add(InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm"))
                        bot.send_message(chat_id=message.chat.id, text=f"<b>API do Mercado Pago, OK ✅</b>\n\n<b>Seu Token:</b> {novo_token}", reply_markup=menu)
                        # Reiniciar o bot após alterar o token
                        os.system('service botssh restart')
                
                keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
                cancel_button = KeyboardButton("Cancelar")
                keyboard.add(cancel_button)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                msg = bot.send_message(call.message.chat.id, f"<b>Config. Token MercadoPago</b>\n\nEnvie seu token para adicionar/atualizar:", reply_markup=keyboard)
                bot.register_next_step_handler(msg, update_token, keyboard)

            # Definir canais de notificações de venda
            if call.data == "notifications":
                def add_canal(message, keyboard):
                    if message.text == "Cancelar":
                        menu = InlineKeyboardMarkup(row_width=1)
                        menu.add(InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm"))
                        bot.send_message(message.chat.id, "Você cancelou o envio de um canal para notificações de vendas.", reply_markup=menu)

                    else:
                        canal_username = message.text
                        canal_info = bot.get_chat(f"{canal_username}")
                        canal_id = canal_info.id
                        print(canal_username)
                        print(canal_id)

                        try:
                            con = sqlite3.connect('database.db')
                            cursor = con.cursor()
                            cursor.execute("INSERT OR IGNORE INTO leads (user_id, nome) VALUES (?, ?)", (canal_id, canal_username))
                            con.commit()
                            bot.send_message(message.chat.id, f"Prontinho. Irei notificar no canal {canal_username} quando novas compras forem realizadas!")
                            bot.send_message(canal_id, f"Este canal a partir de agora notificará sempre que uma compra for realizada em nosso bot!")
                        except Exception as e:
                            print(f"Erro na execução do SQL: {e}")
                            bot.send_message(message.chat.id, "Erro na execução do SQL. Reinicie seu bot e tente novamente mais tarde.")
                        finally:
                            cursor.close()
                            con.close()
    
                keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
                cancel_button = KeyboardButton("Cancelar")
                keyboard.add(cancel_button)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                msg = bot.send_message(call.message.chat.id, f"<b>🔔 Notificações de venda 💰️</b>\n"
                                                             f"Para definir um canal onde serão enviadas as notificações de venda, você precisa adicionar adicionar seu bot como administrador do canal, e conceder todas as permissões (exceto a de adicionar novos adms).\n\n"
                                                             f"Feito? Agora me envie o nome de usuário do seu canal:\n"
                                                             f"<b>Por exemplo:</b> <code>@canal_speednet</code>")
                bot.register_next_step_handler(msg, add_canal, keyboard)

            # Configurar/add token da api EncurtaNET
            if call.data == "token_encurta":
                def update_token(message, keyboard):
                    if message.text == "Cancelar":
                        menu = InlineKeyboardMarkup(row_width=1)
                        menu.add(InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm"))
                        bot.send_message(message.chat.id, "Edição de API EncurtaNET foi cancelada.", reply_markup=menu)

                    else:
                        novo_token = message.text
                        con = sqlite3.connect('database.db')
                        cursor = con.cursor()
                        cursor.execute('UPDATE bot_config SET api_encurta = ? WHERE id = ?', (novo_token, 1))
                        con.commit()
                        con.close()
                        menu = InlineKeyboardMarkup(row_width=1)
                        menu.add(InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm"))
                        bot.send_message(chat_id=message.chat.id, text=f"<b>API EncurtaNET Configurado ✅</b>\n\n<b>Seu Token:</b> {novo_token}", reply_markup=menu)
                    
                # msg = bot.edit_message_text(f"<b>Config. Token EncurtaNET</b>\n\nEnvie seu token da API, ele pode ser encontrado aqui: https://encurta.net/member/tools/api", call.message.chat.id, call.message.message_id, disable_web_page_preview=True)
                # bot.register_next_step_handler(msg, update_token)
                #
                keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
                cancel_button = KeyboardButton("Cancelar")
                keyboard.add(cancel_button)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                msg = bot.send_message(call.message.chat.id, f"<b>Config. Token EncurtaNET</b>\n\nEnvie seu token da API, ele pode ser encontrado aqui: https://encurta.net/member/tools/api", disable_web_page_preview=True, reply_markup=keyboard)
                bot.register_next_step_handler(msg, update_token, keyboard)

            # Gerenciar Link do Grupo de Suporte
            if call.data == "definir_suporte":
                def salvar_link(message):
                    grupo_url = message.text

                    # Verificar se o usuário tentou cancelar o envio
                    if grupo_url == "Cancelar":
                        menu = InlineKeyboardMarkup(row_width=1)
                        menu.add(InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm"))
                        bot.send_message(admin_id, "🛎 O envio ou tualização do link de suporte foi cancelado!", reply_markup=menu)
                    
                    else:
                        if validators.url(grupo_url):
                            con = sqlite3.connect('database.db')
                            cursor = con.cursor()
                            cursor.execute("UPDATE bot_config SET gp_suporte_url = ?", (grupo_url,))
                            con.commit()
                            menu = InlineKeyboardMarkup(row_width=1)
                            menu.add(InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm"))
                            bot.send_message(message.chat.id, "✅ Grupo de Suporte Adicionado ou Atualizado com Sucesso!", reply_markup=menu)
                        
                        else:
                            msg = bot.send_message(admin_id, "❌ <b>A mensagem enviada não é um link válido.</b>\n\n"
                                                    "Por favor envie um link com http:// ou https://")
                            bot.register_next_step_handler(msg, salvar_link)
                        
                menu = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
                cancel_button = KeyboardButton("Cancelar")
                menu.add(cancel_button)
                bot.delete_message(call.message.chat.id, call.message.id)
                msg = bot.send_message(admin_id, "<b>Envie o link do seu grupo de suporte</b> <i>(precisa ter http ou https)</i>\n\n"
                                                "Para cancelar, envie '<code>Cancelar</code>' ou clique no botão 'Cancelar' abaixo", reply_markup=menu)
                bot.register_next_step_handler(msg, salvar_link)

            # Enviar Mensagem para todos os clientes
            if call.data == "send_notify":
                def notificar_usuarios(message):
                    con = sqlite3.connect('database.db')
                    cursor = con.cursor()
                    cursor.execute('SELECT * FROM leads')
                    usuarios = cursor.fetchall()
                    total = len(usuarios)
                    bot.send_message(admin_id, f"Ok, Sua mensagem será enviada para todos os usuários ativos no bot.\n\nAvisarei quando terminar 😉")
                    # Definir o nível de logging para registrar apenas erros
                    logging.basicConfig(level=logging.ERROR)
                    msgs_enviadas = 0
                    usuarios_ignorados = 0
                    
                    # Dividir em lotes de 500 usuários, com um lote adicional para os usuários restantes
                    for i in range(0, total, 500):
                        if i + 500 < total:
                            lote = usuarios[i:i+500]
                        else:
                            lote = usuarios[i:]
                        # Enviar cada lote
                        for usuario in lote:
                            try:
                                bot.copy_message(usuario[0], message.chat.id, message.message_id)
                                time.sleep(1)
                                msgs_enviadas += 1
                            except Exception as e:
                                # Registar o erro no log
                                logging.error(f"Erro ao enviar mensagem para o usuário {usuario}: {e}")
                                usuarios_ignorados += 1
                                # bot.send_message(chat_id, f"Erro ao enviar mensagem para o usuário com ID = {usuario}:\n\nErro: {e}")
                                continue
                            finally:
                                con.close()
                        # Pausar por 5 minutos antes de enviar o próximo lote
                        time.sleep(300)
                    
                    # Enviar mensagem de conclusão
                    bot.send_message(admin_id, f"Terminado! {msgs_enviadas} mensagens foram enviadas com sucesso para {total-usuarios_ignorados} usuários.")


                    # Enviar mensagem de confirmação ao administrador do bot
                    menu = InlineKeyboardMarkup(row_width=1)
                    menu.add(InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm"))
                    bot.send_message(admin_id, f"<b>✅ Prontinho! Mensagem enviada com sucesso!</b>\n\n{msgs_enviadas} usuários receberam sua mensagem.\n\n{usuarios_ignorados} usuários foram ignorados, eles podem ter parado o bot ou deletado o historico de mensagens com o bot.", reply_markup=menu)

                # global chat_id
                # chat_id = call.message.chat.id
                msg = bot.edit_message_text(f"Ok, envie a mensagem que deseja entregar aos usuários:", call.message.chat.id, call.message.message_id)
                bot.register_next_step_handler(msg, notificar_usuarios)

            if call.data == "check_user":
                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute('SELECT checkuser, check_user_port FROM bot_config')
                dados = cursor.fetchone()
                checkuser = dados[0]
                CHECK_USER_PORT = dados[1]

                mensagem = ("<b>👤 API CheckUser Manager ⚙️</b>\n\n"
                            "<i>Esse recurso ativa a API de checkuser que pode ser utilizada em apps baseados no Dtunnel e Conectas4G para obter informações do usuario como o <b>numero de dispositivos conectados</b> e a <b>data do vencimento</b>, mas o nosso tem um recurso adicional: Limitar o numero de usuarios que podem se conectar a um login. Por exemplo, se o login de fulano tem limite para 1 dispositivo, ele só vai conseguir utilizar 1 dispositivo por vez.</i>\n\n")
    
                menu = telebot.types.InlineKeyboardMarkup(row_width=2)
                ativar = telebot.types.InlineKeyboardButton("✅ Ativar", callback_data="ativar_checkuser")
                desativar = telebot.types.InlineKeyboardButton("❌ Desativar", callback_data="desativar_checkuser")
                gerenciar_porta = telebot.types.InlineKeyboardButton("⚙️ Mudar porta", callback_data="checkuser_port")
                if checkuser == "ativado":
                    menu.add(desativar, gerenciar_porta)
                    mensagem += (f"<b>Status Atual:</b> Ativado ✅\n"
                                 f"<b>API Checkuser Dtunnel:</b>\n<code>http://{ip}:{CHECK_USER_PORT}</code>\n"
                                 f"<b>API Checkuser Conecta4G:</b>\n<code>http://{ip}:{CHECK_USER_PORT}/checkUser</code>\n\n"
                                 f"<i>Você pode alterar a porta para uma de sua escolha, desde que a porta em questão não esteja sendo usada por outro serviço ok?</i>")
                else:
                    menu.add(ativar, gerenciar_porta)
                    mensagem += (f"<b>Status Atual:</b> Desativado ❌\n\n")
                back_button = InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")

                menu.add(back_button)
                bot.edit_message_text(mensagem, call.from_user.id, call.message.id, reply_markup=menu)
                cursor.close()
                con.close()

            if call.data == "ativar_checkuser":
                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute("UPDATE bot_config SET checkuser = 'ativado' WHERE rowid = 1")
                con.commit()
                cursor.execute('SELECT checkuser, check_user_port FROM bot_config')
                dados = cursor.fetchone()
                checkuser = dados[0]
                CHECK_USER_PORT = dados[1]

                mensagem = ("<b>👤 API CheckUser Manager ⚙️</b>\n\n"
                            "<i>Esse recurso ativa a API de checkuser que pode ser utilizada em apps baseados no Dtunnel e Conectas4G para obter informações do usuario como o <b>numero de dispositivos conectados</b> e a <b>data do vencimento</b>, mas o nosso tem um recurso adicional: Limitar o numero de usuarios que podem se conectar a um login. Por exemplo, se o login de fulano tem limite para 1 dispositivo, ele só vai conseguir utilizar 1 dispositivo por vez.</i>\n\n")
    
                menu = telebot.types.InlineKeyboardMarkup(row_width=2)
                ativar = telebot.types.InlineKeyboardButton("✅ Ativar", callback_data="ativar_checkuser")
                desativar = telebot.types.InlineKeyboardButton("❌ Desativar", callback_data="desativar_checkuser")
                gerenciar_porta = telebot.types.InlineKeyboardButton("⚙️ Mudar porta", callback_data="checkuser_port")                
                if checkuser == "ativado":
                    menu.add(desativar, gerenciar_porta)
                    mensagem += (f"<b>Status Atual:</b> Ativado ✅\n"
                                 f"<b>API Checkuser Dtunnel:</b>\n<code>http://{ip}:{CHECK_USER_PORT}</code>\n"
                                 f"<b>API Checkuser Conecta4G:</b>\n<code>http://{ip}:{CHECK_USER_PORT}/checkUser</code>\n\n"
                                 f"<i>Você pode alterar a porta para uma de sua escolha, desde que a porta em questão não esteja sendo usada por outro serviço ok?</i>")
                else:
                    menu.add(ativar, gerenciar_porta)
                    mensagem += (f"<b>Status Atual:</b> Desativado ❌\n\n")

                mensagem += (f"Você pode alterar essa configuração quando quiser, mas tenha a consiencia de evitar ficar alterando isso muitas vezes ok?")
                back_button = InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")

                menu.add(back_button)
                bot.edit_message_text(mensagem, call.from_user.id, call.message.id, reply_markup=menu)
                cursor.close()
                con.close()

                # inicia o checkuser
                checkuser_manager.start()

            if call.data == "desativar_checkuser":
                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute("UPDATE bot_config SET checkuser = 'desativado' WHERE rowid = 1")
                con.commit()
                cursor.execute('SELECT checkuser FROM bot_config')
                dados = cursor.fetchone()
                checkuser = dados[0]

                mensagem = ("<b>👤 API CheckUser Manager ⚙️</b>\n\n"
                            "<i>Esse recurso ativa a API de checkuser que pode ser utilizada em apps baseados no Dtunnel e Conectas4G para obter informações do usuario como o <b>numero de dispositivos conectados</b> e a <b>data do vencimento</b>, mas o nosso tem um recurso adicional: Limitar o numero de usuarios que podem se conectar a um login. Por exemplo, se o login de fulano tem limite para 1 dispositivo, ele só vai conseguir utilizar 1 dispositivo por vez.</i>\n\n")
    
                menu = telebot.types.InlineKeyboardMarkup(row_width=2)
                ativar = telebot.types.InlineKeyboardButton("✅ Ativar", callback_data="ativar_checkuser")
                desativar = telebot.types.InlineKeyboardButton("❌ Desativar", callback_data="desativar_checkuser")
                gerenciar_porta = telebot.types.InlineKeyboardButton("⚙️ Mudar porta", callback_data="checkuser_port")
                if checkuser == "ativado":
                    menu.add(desativar, gerenciar_porta)
                    mensagem += (f"<b>Status Atual:</b> Ativado ✅\n\n")
                else:
                    menu.add(ativar, gerenciar_porta)
                    mensagem += (f"<b>Status Atual:</b> Desativado ❌\n\n")

                mensagem += (f"Você pode alterar essa configuração quando quiser, mas tenha a consiencia de evitar ficar alterando isso muitas vezes ok?")
                back_button = InlineKeyboardButton("🔙 Voltar ao Painel", callback_data="painel_adm")

                menu.add(back_button)
                bot.edit_message_text(mensagem, call.from_user.id, call.message.id, reply_markup=menu)
                cursor.close()
                con.close()

                # Para o Checkuser
                checkuser_manager.stop()

            if call.data == "checkuser_port":
                def trocar_porta(msg):
                    menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                    back_button = InlineKeyboardButton("🔙 Voltar ao Checkuser", callback_data="check_user")
                    menu.add(back_button)
                    
                    if msg.text == "/cancelar":
                        bot.send_message(call.message.chat.id, "Entendi. Ação cancelada! ❌", reply_markup=menu)
                    else:
                        try:
                            nova_porta = int(msg.text)
                            con = sqlite3.connect('database.db')
                            cursor = con.cursor()
                            cursor.execute("UPDATE bot_config SET check_user_port = ? WHERE rowid = 1", (nova_porta,))
                            con.commit()
                            cursor.execute('SELECT checkuser, check_user_port FROM bot_config WHERE rowid = 1')
                            resposta = cursor.fetchone()
                            CHECKUSER_STATUS = resposta[0]
                            
                            if resposta:
                                CHECK_USER_PORT = resposta[1]
                            else:
                                CHECK_USER_PORT = "Não configurado"
                            con.close()

                            if CHECK_USER_STATUS == "ativado":
                                # reinicia o checkuser
                                checkuser_manager.stop()
                                checkuser_manager.start()
                            bot.send_message(call.message.chat.id, f"✅ <b>Feito! Nova porta:</b> {CHECK_USER_PORT}", reply_markup=menu)
                        except ValueError:
                            bot.send_message(call.message.chat.id, "Por favor, forneça um número válido para a porta.", reply_markup=menu)

                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute('SELECT check_user_port FROM bot_config WHERE rowid = 1')
                resposta = cursor.fetchone()
                cursor.close()
                con.close()
                
                if resposta:
                    CHECK_USER_PORT = resposta[0]
                else:
                    CHECK_USER_PORT = "Não configurado"

                mensagem = (f"<b>SUA PORTA ATUAL É:</b> {CHECK_USER_PORT}\n\n"
                            f"Qual a nova porta que deseja atribuir ao checkuser? <b>Lembre-se:</b> <u>A porta não pode estar sendo usada por outro serviço</u>\n\n"
                            f"❌ <b>Desistiu? Envie /cancelar</b>")
                msg = bot.edit_message_text(mensagem, call.from_user.id, call.message.id)
                bot.register_next_step_handler(msg, trocar_porta)

        # =============================================================================================

            if call.data == "baixar_app":
                con = sqlite3.connect('database.db')
                cursor = con.cursor()
                cursor.execute('SELECT app_link, app_id FROM apps')
                resposta = cursor.fetchone()
                app_link = resposta[0]
                app_id = resposta[1]
                cursor.close()
                con.close()
                menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                download_button = telebot.types.InlineKeyboardButton(text='📥 Clique Para Baixar 📥', url=app_link)
                back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Início", callback_data="voltar_ao_inicio")
                menu.add(download_button, back_button)

                # Obtenha informações do bot
                bot_info = bot.get_me()
                bot_username = bot_info.username

                # Enviar App pelo id e o menu com botões
                bot.send_document(call.from_user.id, document=f"{app_id}", caption=f"APK by @{bot_username}")
                bot.send_message(call.from_user.id, "Você também pode baixar o app pela play store, google drive, dropbox ou canal do telegram, clicando no botão abaixo.", reply_markup=menu)

            # Criar Teste
            if call.data == "ssh_teste":
                bot.delete_message(call.from_user.id, call.message.id)
                chat_id = str(call.from_user.id)

                try:
                    # Conectar ao banco de dados
                    with sqlite3.connect('database.db') as con:
                        cursor = con.cursor()

                        # Verificar se o user_id (como string) está na tabela testes
                        cursor.execute("SELECT user_id, login, senha, validade FROM testes WHERE user_id = ?", (chat_id,))
                        result = cursor.fetchone()

                        if result:
                            # Se o user_id existe na tabela testes
                            login, senha, validade_str = result[1], result[2], result[3]
                            validade = datetime.fromisoformat(validade_str)

                            # Comparar a data/hora de validade com a data/hora atual
                            if datetime.now() < validade:
                                # O teste ainda é válido, então formate o tempo restante e envie de volta ao usuário
                                tempo_restante = validade - datetime.now()
                                minutos_restantes = int(tempo_restante.total_seconds() / 60)

                                menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                                app_button = telebot.types.InlineKeyboardButton("📥 Baixar nosso APP", callback_data="baixar_app")
                                back_button = InlineKeyboardButton("🔙 Voltar ao Menu", callback_data="voltar_ao_inicio")
                                menu.add(app_button, back_button)
                                bot.send_message(chat_id, f'<b>✅ Você já possui um Teste Grátis ativo!</b>\n\n'
                                f'👤 <b>Login:</b> <code>{login}</code>\n'
                                f'🔐 <b>Senha:</b> <code>{senha}</code>\n'
                                f'⏰️ <b>Tempo Restante:</b> {minutos_restantes} minutos\n\n'
                                '⚠️ <i>Lembre-se, é necessário <b>abrir o aplicativo com internet</b> para sincronizar com as configurações mais recentes das operadoras!</i>',
                                reply_markup=menu)
                            
                            else:
                                # Converter validade_str em um objeto datetime
                                validade = datetime.fromisoformat(validade_str)
                                # Adicionar 30 dias à data de validade
                                nova_validade = validade + timedelta(days=30)
                                # Obter a data atual
                                data_atual = datetime.now()
                                # Calcular a diferença entre a nova_validade e a data atual
                                dias_faltando = (nova_validade - data_atual).days
                                # Verificar se é possível criar um novo teste
                                if dias_faltando < 1:
                                    # Excluir a linha referente ao teste anterior na tabela testes
                                    cursor.execute("DELETE FROM testes WHERE user_id = ?", (chat_id,))

                                    # Daqui pra baixo o código para gerar o teste
                                    dicionario = string.ascii_letters + string.digits
                                    # Define o número mínimo e máximo de caracteres
                                    no_minimo = 5
                                    no_maximo = 8

                                    # Cria as variáveis login e senha com caracteres aleatórios
                                    login = ''.join(secrets.choice(dicionario) for i in range(random.randint(no_minimo, no_maximo)))
                                    senha = ''.join(secrets.choice(string.digits) for i in range(random.randint(no_minimo, no_maximo)))
                                    validade = 90  # Tempo em minutos
                                    limite = '1'  # Limite de dispositivos

                                    # Cria o comando para gerar a conta SSH
                                    comando = f"{pathlib.Path.cwd()}/teste.sh {login} {senha} {validade} {limite}"
                                    os.system(comando)

                                    # Data e hora atuais
                                    agora = datetime.now()
                                    # Calcular a nova data/hora no futuro
                                    futuro = agora + timedelta(minutes=validade)
                                    # Formatar a data/hora como deseja para exibição
                                    formato_legível = "%d/%m às %H:%M"
                                    hora_legível = futuro.strftime(formato_legível)
                                    # Formatar para o armazenamento no banco de dados (ISO 8601 é um bom formato padrão)
                                    expirar_db = futuro.isoformat()

                                    cursor.execute("INSERT INTO testes (user_id, login, senha, validade) VALUES (?, ?, ?, ?)", (chat_id, login, senha, expirar_db))
                                    con.commit()
                                    menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                                    app_button = telebot.types.InlineKeyboardButton("📥 Baixar nosso APP", callback_data="baixar_app")
                                    back_button = InlineKeyboardButton("🔙 Voltar ao Menu", callback_data="voltar_ao_inicio")
                                    menu.add(app_button ,back_button)
                                    bot.send_message(chat_id, f'<b>✅ Teste Grátis Criado!</b>\n\n💡'
                                    f'⚠️ <b>Atenção:</b> Seu tempo de teste começa a contar exatamente agora. Ao clicar no usuário já copia automaticamente, cole no app, depois faça o mesmo com a senha!\n\n'
                                    f'👤 <b>Login:</b> <code>{login}</code>\n'
                                    f'🔐 <b>Senha:</b> <code>{senha}</code>\n'
                                    f'⏰️ <b>Expira:</b> {hora_legível}\n'
                                    f'📲 <b>Limite:</b> 1 Dispositivo\n\n'
                                    '⚠️ <i>É necessário <b>abrir o aplicativo com internet</b> para sincronizar com as configurações mais recentes das operadoras!</i>', reply_markup=menu)
                                else:
                                    # Informar os dias restantes para liberar a criação de outro teste
                                    menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                                    back_button = telebot.types.InlineKeyboardButton("🔙 Voltar ao Menu", callback_data="voltar_ao_inicio")
                                    menu.add(back_button)
                                    bot.send_message(chat_id, f'<b>Um teste foi criado recentemente!</b>\n\n'
                                                    f'Você poderá criar um teste grátis novamente só daqui a {dias_faltando} dias!\n',
                                                    reply_markup=menu)
                        
                        else:
                            # Se o id do usuário não existir na tabela testes
                            dicionario = string.ascii_letters + string.digits
                            # Define o número mínimo e máximo de caracteres
                            no_minimo = 5
                            no_maximo = 8

                            # Cria as variáveis login e senha com caracteres aleatórios
                            login = ''.join(secrets.choice(dicionario) for i in range(random.randint(no_minimo, no_maximo)))
                            senha = ''.join(secrets.choice(string.digits) for i in range(random.randint(no_minimo, no_maximo)))
                            validade = 90  # Tempo em minutos
                            limite = '1'  # Limite de dispositivos

                            # Cria o comando para gerar a conta SSH
                            comando = f"{pathlib.Path.cwd()}/teste.sh {login} {senha} {validade} {limite}"
                            os.system(comando)

                            # Data e hora atuais
                            agora = datetime.now()
                            # Calcular a nova data/hora no futuro
                            futuro = agora + timedelta(minutes=validade)
                            # Formatar a data/hora como deseja para exibição
                            formato_legível = "%d/%m às %H:%M"
                            hora_legível = futuro.strftime(formato_legível)
                            # Formatar para o armazenamento no banco de dados (ISO 8601 é um bom formato padrão)
                            expirar_db = futuro.isoformat()

                            cursor.execute("INSERT INTO testes (user_id, login, senha, validade) VALUES (?, ?, ?, ?)", (chat_id, login, senha, expirar_db))
                            con.commit()
                            menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                            app_button = telebot.types.InlineKeyboardButton("📥 Baixar nosso APP", callback_data="baixar_app")
                            back_button = InlineKeyboardButton("🔙 Voltar ao Menu", callback_data="voltar_ao_inicio")
                            menu.add(app_button ,back_button)
                            bot.send_message(chat_id, f'<b>✅ Teste Grátis Criado!</b>\n\n💡'
                            f'⚠️ <b>Atenção:</b> Seu tempo de teste começa a contar exatamente agora. Ao clicar no usuário já copia automaticamente, cole no app, depois faça o mesmo com a senha!\n\n'
                            f'👤 <b>Login:</b> <code>{login}</code>\n'
                            f'🔐 <b>Senha:</b> <code>{senha}</code>\n'
                            f'⏰️ <b>Expira:</b> {hora_legível}\n'
                            f'📲 <b>Limite:</b> 1 Dispositivo\n\n'
                            '⚠️ <i>É necessário <b>abrir o aplicativo com internet</b> para sincronizar com as configurações mais recentes das operadoras!</i>', reply_markup=menu)

                except sqlite3.Error as e:
                    # Lida com erros do SQLite
                    print(f"Erro no SQLite: {e}")
                
                except Exception as e:
                    # Lida com outras exceções
                    print(f"Erro: {e}")

                finally:
                    # Fechar a conexão com o banco de dados
                    cursor.close()
        
            # indicar bot
            if call.data =='indicar_bot':
                # Obtenha informações do bot
                bot_info = bot.get_me()
                bot_username = bot_info.username
                # Crie o link do bot
                bot_url = f"https://t.me/{bot_username}"
                link = f'{bot_url}?start=code={call.from_user.id}'
                print(link)
                mensagem = f'Olá, estou indicando você para usar o melhor serviço de VPN VIP do Brasil! Clique no link abaixo para adquirir:\n\n{link}'
                share_link = f"https://t.me/share/url?text={mensagem}"
                menu = telebot.types.InlineKeyboardMarkup(row_width=1)
                download_button = telebot.types.InlineKeyboardButton(text='INDICAR USUÁRIO', url=f'{share_link}')
                back_button = InlineKeyboardButton("🔙 Voltar ao início", callback_data="voltar_ao_inicio")
                menu.add(download_button, back_button)
                bot.edit_message_text(f"""<b>Ganhe por indicações</b>

        <b>Como funciona?</b> Clicando no botão abaixo você irá compratilhar seu link de indicação. Ao indicar nosso bot e o usuário que você indicar realizar uma compra, você receberá uma comissão de 25% pela venda (ou seja, se o valor total for R$20, você ganhará R$5 por ter indicado). <b>A comissão é recorrente</b>, o que signica que você também receberá a comissão nas campras futuras. Legal né?

        <b>Regras:</b> A comissão será entregue a ultima pessoa que indicou, ou seja: Se você indicar, e a pessoa não comprar de imediato, se outra pessoa o indicar depois e o cliente comprar, a ultima pessoa que indicou é que receberá a comissão ok?

        <b>Saques:</b> Seu saldo ganho pelas comissões pode ser sacado, basta solicitar quanto atingir o valor mínimo (20 Reais), mas ele pode valer o dobro se usar para comprar login no bot.

        Por exemplo: Se seu saldo for de 10,00 R$, ele vale 20,00 se preferir comprar login 30 dias no bot.""", call.from_user.id, call.message.id, reply_markup=menu)
                
            # Opção de voltar
            if call.data == 'voltar_ao_inicio':
                markup = menu_inicial(call.from_user.id)
                bot.edit_message_text(f"<b>👋🏼😁 Oiie, sou o bot de SSH VIP!</b>\n\n"
                "<i>Antes de mais nada, eu só respondo mensagens específicas, fui programado para interagir apenas através do meu menu ok?</i>  Agora vamos lá, <b>como posso te ajudar?</b>\n\n"
                "<b>DICA:</b> Apenas clique em um dos botões abaixo e eu irei atender a opção solicitada!", call.from_user.id, call.message.id, reply_markup=markup)

            if call.data == 'ssh_premium':
                def criar_teclado_inline():
                    con = sqlite3.connect('database.db')
                    cursor = con.cursor()
                    cursor.execute("SELECT quantidade, validade, valor FROM planos_db")
                    planos = cursor.fetchall()

                    keyboard_buttons = []
                    for plano in planos:
                        logins = plano[0]
                        validade = plano[1]
                        preco = plano[2]
                        button = InlineKeyboardButton(f"{logins} login(s) {validade} dias - R${preco}", callback_data=f"comprar,{logins},{validade},{preco}")
                        keyboard_buttons.append([button])

                    back_button = InlineKeyboardButton("🔙 Voltar ao início", callback_data="voltar_ao_inicio")
                    keyboard_buttons.append([back_button])
                    keyboard = InlineKeyboardMarkup(keyboard_buttons)
                    return keyboard
                    con.close()

                if call.data == 'voltar_ao_inicio':
                    menu_inicial(call.message.chat.id)
                else:
                    chat_id = call.message.chat.id
                    keyboard = criar_teclado_inline()
                    bot.edit_message_text(f"""<b>👑 Esses são nossos planos VIP</b>\n\n<i>Escolha o plano de acordo com a quantidade de dispositivos em que você pretende usar o serviço:</i>""", call.from_user.id, call.message.id, reply_markup=keyboard)

            if call.data.startswith('comprar'):
                def obter_email(message):
                    email = message.text
                    # Validar o email usando a biblioteca 'validators'
                    if validators.email(email):
                        mercadoPago.funcoes.cobrar(bot, chat_id, client_name, email, logins, validade, preco)
                        gerar_compra(call, logins, validade, preco)
                        bot.delete_message(call.message.chat.id, call.message.id)
                    else:
                        # Se o email não for válido, edite a mensagem anterior
                        msg = bot.send_message(chat_id, "❌ <b>O Email informado não é inválido.</b>\n\n"
                        "🔒 <b>Mercado Pago</b> <i>(Instituição que usamos para receber os pagamentos)</i> solicita o envio de um email para poder validar a compra e lhe informar o <b>status do pagamento.</b>\n\n"
                        "📧 Isso nos ajuda a manter você informado, inclusive em casos de extorno por pagamentos recusados, por exemplo.\n\n"
                        "📩 Por favor, informe um email válido:")
                        bot.register_next_step_handler(msg, obter_email)

                def gerar_compra(call, logins, validade, preco):  # recebe logins e preco como argumentos
                    print('Deu certo!')

                # extrai logins e preco da callback_data do botão
                argumentos = call.data.split(',')
                chat_id = str(call.message.chat.id)
                client_name = call.from_user.first_name
                logins = int(argumentos[1])
                validade = int(argumentos[2])
                preco = int(argumentos[3])

                # Edita a mensagem atual (que continha o botão) para solicitar o email do usuário
                bot.edit_message_text(chat_id=chat_id, message_id=call.message.id, 
                                    text="🔒 <b>Mercado Pago</b> <i>(Instituição que usamos para receber os pagamentos)</i> solicita o envio de um email para poder validar a compra e lhe informar o <b>status do pagamento.</b>\n\n"
                    "📧 Isso nos ajuda a manter você informado, inclusive em casos de extorno por pagamentos recusados, por exemplo.\n\n"
                    "📩 Por favor, informe seu email:")
                bot.register_next_step_handler(call.message, obter_email)

    else:
        print ("Falha na solicitação. Código de status:", response.status_code)
# Check API Data Finish ===================================================================



        
# ================================================================================================= #

bot.infinity_polling(skip_pending=True)
